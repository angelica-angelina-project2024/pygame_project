from Parameters import screen


class Cube:
    def __init__(self, x, y, width, image, speed):
        self.x = x
        self.y = y
        self.width = width
        self.image = image
        self.speed = speed

    def moving(self):
        if self.x >= -self.width:
            screen.blit(self.image, (self.x, self.y))
            self.x -= self.speed
            return True
        else:
            return False

    def removing(self, distance, y, width, image):
        self.x = distance
        self.y = y
        self.width = width
        self.image = image
        screen.blit(self.image, (self.x, self.y))