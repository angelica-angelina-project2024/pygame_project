from Parameters import *
from Images import *


class Shooting:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.speed_x = 8
        self.speed_y = 0
        self.point_x = 0
        self.point_y = 0

    def moving(self):
        self.x += self.speed_x
        if self.x <= screen_width:
            screen.blit(shoot_image, (self.x, self.y))
            return True
        else:
            return False

    def find_distance(self, point_x, point_y):
        self.point_x = point_x
        self.point_y = point_y
        delta_x = point_x - self.x
        counter_up = delta_x // self.speed_x
        if self.y >= point_y:
            delta_y = self.y - point_y
            self.speed_y = delta_y / counter_up
        else:
            delta_y = point_y - self.y
            self.speed_y = -(delta_y / counter_up)

    def move_to_point(self, reverse=False):
        if not reverse:
            self.x += self.speed_x
            self.y -= self.speed_y
        else:
            self.x -= self.speed_x
            self.y += self.speed_y
        if self.x <= screen_width and not reverse:
            screen.blit(shoot_image, (self.x, self.y))
            return True
        elif self.x >= 0 and reverse:
            screen.blit(shoot_image, (self.x, self.y))
            return True
        else:
            return False