import pygame


pygame.display.set_caption('Funny animals')
game_icon = pygame.image.load('images/icon.png')
pygame.display.set_icon(game_icon)


pygame.mixer.music.load('sounds/background.mp3')
pygame.mixer.music.set_volume(0.3)

screen_width = 800
screen_height = 600

screen = pygame.display.set_mode((screen_width, screen_height))

mouse_counter = 0
need_draw_click = False

hero_width = 60
hero_height = 90
hero_x = screen_width // 3
hero_y = screen_height - hero_height - 50


clock = pygame.time.Clock()

cube_width = 20
cube_height = 70
cube_x = screen_width - 50
cube_y = screen_height - cube_height - 100

obstacles_sizes = [80, 431, 80, 431, 80, 431, 80, 431]
hero_jumping = False
counter_jump = 35
scores = 0

counter_animation = 0
lives = 3
scores_max = 0
above_max = 0

counter_bullets = 0
damage = False
my_font = pygame.font.SysFont('Arial', 40, bold=True)
pause_text = open('text/pause_message.txt').read()
end_text = open('text/game_over.txt', 'r').read()

fps = 60

