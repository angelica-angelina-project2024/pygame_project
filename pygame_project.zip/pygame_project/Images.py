import pygame

pygame.init()

health_image = pygame.image.load('images/heart.png')

ground = pygame.image.load('images/fon.jpeg')
obstacles = [pygame.image.load('images/tree_1.png'), pygame.image.load('images/tree_2.png'),
             pygame.image.load('images/tree_3.png'), pygame.image.load('images/tree_4.png')]
cows = [pygame.image.load('images/cow1.png'), pygame.image.load('images/cow2.png'),
        pygame.image.load('images/cow3.png'), pygame.image.load('images/cow4.png')]
light_img = [pygame.image.load('effects/Light0.png'), pygame.image.load('effects/Light1.png'),
             pygame.image.load('effects/Light2.png'), pygame.image.load('effects/Light3.png'),
             pygame.image.load('effects/Light4.png'), pygame.image.load('effects/Light5.png'),
             pygame.image.load('effects/Light6.png'), pygame.image.load('effects/Light7.png'),
             pygame.image.load('effects/Light8.png'), pygame.image.load('effects/Light9.png'),
             pygame.image.load('effects/Light10.png')]
dragons = [pygame.image.load('images/dragon1.png'), pygame.image.load('images/dragon2.png'),
           pygame.image.load('images/dragon3.png'), pygame.image.load('images/dragon4.png')]
shoot_image = pygame.image.load('images/fire.png')
mods_image = pygame.image.load('images/mods_fon.jpg')
shoot_image = pygame.transform.scale(shoot_image, (50, 40))
health_image = pygame.transform.scale(health_image, (30, 30))
rain_img = pygame.image.load('images/rain.png')
ground1 = pygame.image.load('images/fon.jpeg')
ground2 = pygame.image.load('images/fon2.jpeg')
