from Game import *

pygame.init()

new_game = Game()
new_game.menu()
pygame.quit()