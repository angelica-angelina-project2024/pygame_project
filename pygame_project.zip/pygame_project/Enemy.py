import random
from Shooting import *
from Images import *


class Enemy:
    def __init__(self, behind_y):
        self.x = random.randrange(550, 730)
        self.behind_y = behind_y
        self.speed = 3
        self.point_y = self.speed * random.randrange(20, 70)
        self.y = behind_y
        self.image_counter = 0
        self.counter_hide = 0
        self.arrival = True
        self.hidding = False
        self.width = 100
        self.height = 90
        self.cooldown = 0
        self.all_bullets = []

    def draw(self):
        if self.image_counter == 64:
            self.image_counter = 0
        screen.blit(dragons[self.image_counter // 16], (self.x, self.y))
        self.image_counter += 1
        if self.arrival and self.counter_hide == 0:
            return 1
        elif self.hidding:
            return 2
        elif self.counter_hide > 0:
            self.counter_hide -= 1
        return 0

    def arrive_enemy(self):
        if self.y < self.point_y:
            self.y += self.speed
        else:
            self.arrival = False
            self.point_y = self.behind_y

    def hide_enemy(self):
        if self.y > self.point_y:
            self.y -= self.speed
        else:
            self.arrival = True
            self.hidding = False
            self.x = random.randrange(550, 730)
            self.point_y = self.speed * random.randrange(20, 70)
            self.counter_hide = 80

    def check_hit(self, bullet):
        if self.x <= bullet.x <= self.x + self.width:
            if self.y <= bullet.y <= self.y + self.height:
                self.hidding = True

    def shooting(self):
        if not self.cooldown:
            new_bullet = Shooting(self.x, self.y)
            new_bullet.find_distance(hero_x + hero_width // 2, hero_y + hero_height // 2)
            self.all_bullets.append(new_bullet)
            self.cooldown = 200
        else:
            self.cooldown -= 1
        for bullet in self.all_bullets:
            if not bullet.move_to_point(reverse=True):
                self.all_bullets.remove(bullet)