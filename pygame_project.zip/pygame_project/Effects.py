import pygame
import Parameters as p
from Images import light_img


def print_text(message, x, y, font_color='#ffffff', font_size=19):
    font_type = pygame.font.SysFont('Arial', font_size, bold=True)
    text = font_type.render(message, True, font_color)
    p.screen.blit(text, (x, y))


def print_text_main(message, x, y, font_color='#000000'):
    font_type = pygame.font.SysFont('Arial', 60, bold=True)
    text = font_type.render(message, True, font_color)
    p.screen.blit(text, (x, y))


def draw_mouse():
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    mouse_size = [10, 12, 16, 20, 28, 34, 40, 45, 48, 54, 58]

    if click[0] or click[1]:
        p.need_draw_click = True

    if p.need_draw_click:
        draw_x = mouse[0] - mouse_size[p.mouse_counter] // 2
        draw_y = mouse[1] - mouse_size[p.mouse_counter] // 2

        p.screen.blit(light_img[p.mouse_counter], (draw_x, draw_y))
        p.mouse_counter += 1
        if p.mouse_counter == 10:
            p.mouse_counter = 0
            p.need_draw_click = False




