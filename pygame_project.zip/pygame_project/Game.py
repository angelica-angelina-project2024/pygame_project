import pygame
from Button import *
from Cube import *
from Enemy import *
from Effects import *
from Images import *
from Rain import *
from Ball import *


class Game:
    def menu(self):
        pygame.mixer.music.load('sounds/start.mp3')
        pygame.mixer.music.set_volume(0.3)
        pygame.mixer.music.play(-1)
        menu_image = pygame.image.load('images/cow_menu.jpg')
        start_button = Button(300, 63)
        show = True
        while show:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
            screen.blit(menu_image, (0, 0))
            start_button.draw(250, 170, self.game_mods)

            print_text_main('Играть', 310, 164)
            draw_mouse()
            pygame.display.update()
            clock.tick(p.fps)

    def game_enemies_start(self):
        pygame.mixer.music.load('sounds/background.mp3')
        pygame.mixer.music.set_volume(0.3)
        pygame.mixer.music.play(-1)
        while self.game_enemies():
            p.scores = 0
            p.hero_jumping = False
            p.counter_jump = 35
            p.hero_y = p.screen_height - p.hero_height - 50
            p.lives = 3
            p.counter_bullets = 0

    def start_game(self):
        pygame.mixer.music.load('sounds/background.mp3')
        pygame.mixer.music.set_volume(0.3)
        pygame.mixer.music.play(-1)
        while self.main():
            p.scores = 0
            p.hero_jumping = False
            p.counter_jump = 35
            p.hero_y = p.screen_height - p.hero_height - 50
            p.lives = 3

    def main(self, flag='theme0'):
        cubes = []
        self.make_cube(cubes)
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    pygame.quit()
                    quit()
            if pygame.key.get_pressed()[pygame.K_SPACE]:
                p.hero_jumping = True

            if pygame.key.get_pressed()[pygame.K_p]:
                self.pause()

            if p.hero_jumping:
                self.jump_function()

            if flag == 'theme1':
                screen.blit(ground1, (0, 0))
            if flag == 'theme2':
                rain_group.update()
                screen.blit(ground2, (0, 0))
                rain_group.draw(screen)
            self.count_scores(cubes)
            print_text('Очки:' + str(p.scores), 700, 10)

            self.cubes_drawing(cubes)
            self.drawing_animals()
            if self.collision(cubes):
                pygame.mixer.music.stop()
                pygame.mixer.Sound.play(sound_fall)
                if not self.check_lives():
                    running = False
            self.show_lives()
            draw_mouse()
            pygame.display.update()
            clock.tick(p.fps)
        return self.game_end()

    @staticmethod
    def jump_function():
        if p.counter_jump >= -35:
            if p.counter_jump == 35:
                pygame.mixer.Sound.play(sound_jump)

            if p.counter_jump == -10:
                pygame.mixer.Sound.play(sound_fall)
            p.hero_y -= p.counter_jump / 2.5
            p.counter_jump -= 1
        else:
            p.counter_jump = 35
            p.hero_jumping = False

    @staticmethod
    def make_cube(cube_list):
        random_num = random.randrange(0, 4)
        image = obstacles[random_num]
        obstacle_width = p.obstacles_sizes[random_num * 2]
        obstacle_height = p.obstacles_sizes[random_num * 2 + 1]
        cube_list.append(Cube(screen_width + 20, obstacle_height, obstacle_width, image, 4))

        random_num = random.randrange(0, 4)
        image = obstacles[random_num]
        obstacle_width = p.obstacles_sizes[random_num * 2]
        obstacle_height = p.obstacles_sizes[random_num * 2 + 1]
        cube_list.append(Cube(screen_width + 300, obstacle_height, obstacle_width, image, 4))

        random_num = random.randrange(0, 4)
        image = obstacles[random_num]
        obstacle_width = p.obstacles_sizes[random_num * 2]
        obstacle_height = p.obstacles_sizes[random_num * 2 + 1]
        cube_list.append(Cube(screen_width + 600, obstacle_height, obstacle_width, image, 4))

        random_num = random.randrange(0, 4)
        image = obstacles[random_num]
        obstacle_width = p.obstacles_sizes[random_num * 2]
        obstacle_height = p.obstacles_sizes[random_num * 2 + 1]
        cube_list.append(Cube(screen_width + 900, obstacle_height, obstacle_width, image, 4))

    @staticmethod
    def cube_distance(cube_list):
        max_distance = max(cube_list[0].x, cube_list[1].x, cube_list[2].x, cube_list[3].x)
        if max_distance < p.screen_width:
            distance = p.screen_width
            if distance - max_distance < 50:
                distance += 280
        else:
            distance = max_distance
        random_num = random.randrange(50, 80)
        if random_num == 0:
            distance += random.randrange(700, 800)
        else:
            distance += random.randrange(250, 400)
        return distance

    def cubes_drawing(self, cube_list):
        for cube in cube_list:
            flag = cube.moving()
            if not flag:
                self.return_obstacle(cube_list, cube)

    def return_obstacle(self, objects, obj):
        distance = self.cube_distance(objects)
        random_num = random.randrange(0, 4)
        image = obstacles[random_num]
        obstacle_width = p.obstacles_sizes[random_num * 2]
        obstacle_height = p.obstacles_sizes[random_num * 2 + 1]
        obj.removing(distance, obstacle_height, obstacle_width, image)

    @staticmethod
    def drawing_animals():
        if p.counter_animation == 64:
            p.counter_animation = 0
        screen.blit(cows[p.counter_animation // 16], (p.hero_x, p.hero_y))
        p.counter_animation += 1

    @staticmethod
    def pause():
        flag = True
        pygame.mixer.music.pause()
        while flag:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
            print_text(p.pause_text, 370, 100)
            keys = pygame.key.get_pressed()
            if keys[pygame.K_c]:
                flag = False
            pygame.display.update()
            clock.tick(15)
        pygame.mixer.music.unpause()

    def collision(self, objects):
        for obj in objects:
            if p.hero_height + p.hero_y >= obj.y:
                if obj.x <= p.hero_x <= obj.x + obj.width:
                    if self.check_lives():
                        self.return_obstacle(objects, obj)
                        sound_fall.play()
                        return False
                    else:
                        return True
                elif obj.x <= p.hero_x + p.hero_width <= obj.x + obj.width:
                    if self.check_lives():
                        self.return_obstacle(objects, obj)
                        sound_fall.play()
                        return False
                    else:
                        return True
        return False

    @staticmethod
    def count_scores(objects):
        above_true = 0

        if -20 <= p.counter_jump < 25:
            for obj in objects:
                if p.hero_y + p.hero_width - 5 <= obj.y:
                    if obj.x <= p.hero_x <= obj.x + obj.width:
                        above_true += 1
                    elif obj.x <= p.hero_x + p.hero_width <= obj.x + obj.width:
                        above_true += 1
            p.above_max = max(p.above_max, above_true)

        else:
            if p.counter_jump == -35:
                p.scores += p.above_max
                p.above_max = 0

    @staticmethod
    def check_lives():
        if p.lives > 0 or p.damage:
            p.lives -= 1
        if p.lives == 0:
            pygame.mixer.Sound.play(death_sound)
            return False
        else:
            pygame.mixer.Sound.play(crash_sound)
            return True

    @staticmethod
    def game_end():
        if p.scores > p.scores_max:
            p.scores_max = p.scores
        flag = True
        while flag:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
            print_text(p.end_text, 15, 100)
            print_text('Максимальное количество очков:' + str(p.scores_max), 250, 300)
            keys = pygame.key.get_pressed()
            if keys[pygame.K_n]:
                pygame.mixer.music.load('sounds/background.mp3')
                pygame.mixer.music.set_volume(0.3)
                pygame.mixer.music.play(-1)
                return True
            if keys[pygame.K_ESCAPE]:
                return False
            pygame.display.update()
            clock.tick(15)

    @staticmethod
    def show_lives():
        show = 0
        x = 20
        while show != p.lives:
            screen.blit(health_image, (x, 20))
            x += 40
            show += 1

    @staticmethod
    def draw_enemies(enemies):
        for enemy in enemies:
            action = enemy.draw()
            if action == 1:
                enemy.arrive_enemy()
            elif action == 2:
                enemy.hide_enemy()
            else:
                enemy.shooting()

    @staticmethod
    def check_enemies_hit(bullets, enemies):
        for enemy in enemies:
            for bullet in bullets:
                enemy.check_hit(bullet)

    @staticmethod
    def check_cow_hit(bull):
        if hero_x <= bull.x <= hero_x + hero_width:
            if hero_y <= bull.y <= hero_y + hero_height:
                return True

    def game_mods(self):
        first_button = Button(330, 63)
        second_button = Button(330, 63)
        show = True
        while show:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
            screen.blit(mods_image, (0, 0))
            first_button.draw(250, 170, self.theme_choice1)
            print_text_main('Препятствия', 215, 164)
            second_button.draw(250, 280, self.theme_choice2)
            print_text_main('Враги', 330, 270)
            draw_mouse()
            pygame.display.update()
            clock.tick(p.fps)

    def game_enemies(self, flag='theme0'):
        p.scores = 0
        p.hero_jumping = False
        p.counter_jump = 35
        p.hero_y = screen_height - hero_height - 50
        p.lives = 3
        pygame.mixer.music.load('sounds/background.mp3')
        pygame.mixer.music.set_volume(0.3)
        pygame.mixer.music.play(-1)
        all_button_bullets = []
        all_mouse_bullets = []
        cubes = []
        self.make_cube(cubes)
        running = True
        dragon1 = Enemy(-100)
        dragon2 = Enemy(-50)
        all_dragons = [dragon1, dragon2]
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    pygame.quit()
                    quit()
            mouse = pygame.mouse.get_pos()
            click = pygame.mouse.get_pressed()
            if pygame.key.get_pressed()[pygame.K_SPACE]:
                p.hero_jumping = True
            if pygame.key.get_pressed()[pygame.K_p]:
                self.pause()
            if p.hero_jumping:
                self.jump_function()

            if flag == 'theme1':
                screen.blit(ground1, (0, 0))
            if flag == 'theme2':
                screen.blit(ground2, (0, 0))
                rain_group.update()
                rain_group.draw(screen)
            if not p.counter_bullets:
                if pygame.key.get_pressed()[pygame.K_x]:
                    all_button_bullets.append(Shooting(p.hero_x + p.hero_width, p.hero_y + 15))
                    p.counter_bullets = 50
                elif click[0]:
                    new_bullet = Shooting(p.hero_x + p.hero_width, p.hero_y + 15)
                    new_bullet.find_distance(mouse[0], mouse[1])
                    all_mouse_bullets.append(new_bullet)
                    p.counter_bullets = 50
            else:
                print_text('До перезарядки: ' + str(p.counter_bullets // 10), 482, 10)
                p.counter_bullets -= 1
            for bullet in all_button_bullets:
                if not bullet.moving():
                    all_button_bullets.remove(bullet)
            for bullet in all_mouse_bullets:
                if not bullet.move_to_point():
                    all_mouse_bullets.remove(bullet)

            for dragon in all_dragons:
                for bullet in dragon.all_bullets:
                    if p.hero_x <= bullet.x <= p.hero_x + p.hero_width:
                        if p.hero_y <= bullet.y <= p.hero_y + p.hero_height:
                            p.lives = max(0, p.lives - 1)
                            self.check_lives()
            self.count_scores(cubes)
            print_text('Очки:' + str(p.scores), 700, 10)
            self.cubes_drawing(cubes)
            self.drawing_animals()
            if self.collision(cubes):
                pygame.mixer.music.stop()
                pygame.mixer.Sound.play(sound_fall)
                if not self.check_lives():
                    running = False
            self.show_lives()
            self.draw_enemies(all_dragons)
            self.check_enemies_hit(all_mouse_bullets, all_dragons)
            pygame.display.update()
            clock.tick(p.fps)
        return self.game_end()

    def theme_choice1(self):
        theme1_button = Button(330, 63)
        theme2_button = Button(330, 63)
        show = True
        while show:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
            screen.fill(pygame.Color("white"))
            all_sprites.draw(screen)
            all_sprites.update()
            theme1_button.draw(250, 170, self.start_game1)
            print_text_main('Солнечно', 280, 160)
            theme2_button.draw(250, 280, self.start_game2)
            print_text_main('Дождь', 330, 270)
            pygame.display.flip()
            draw_mouse()
            pygame.display.update()
            clock.tick(p.fps)

    def theme_choice2(self):
        theme1_button = Button(330, 63)
        theme2_button = Button(330, 63)
        show = True
        while show:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
            screen.fill(pygame.Color("white"))
            all_sprites.draw(screen)
            all_sprites.update()
            theme1_button.draw(250, 170, self.game_enemies1)
            print_text_main('Солнечно', 280, 160)
            theme2_button.draw(250, 280, self.game_enemies2)
            print_text_main('Дождь', 330, 270)
            pygame.display.flip()
            draw_mouse()
            pygame.display.update()
            clock.tick(p.fps)

    def game_enemies1(self):
        p.scores = 0
        p.hero_jumping = False
        p.counter_jump = 35
        p.hero_y = screen_height - hero_height - 50
        p.lives = 3
        pygame.mixer.music.load('sounds/background.mp3')
        pygame.mixer.music.set_volume(0.3)
        pygame.mixer.music.play(-1)
        while self.game_enemies(flag='theme1'):
            p.scores = 0
            p.hero_jumping = False
            p.counter_jump = 35
            p.hero_y = screen_height - hero_height - 50
            p.lives = 3
            p.counter_bullets = 0

    def game_enemies2(self):
        p.scores = 0
        p.hero_jumping = False
        p.counter_jump = 35
        p.hero_y = screen_height - hero_height - 50
        p.lives = 3
        pygame.mixer.music.load('sounds/background.mp3')
        pygame.mixer.music.set_volume(0.3)
        pygame.mixer.music.play(-1)
        while self.game_enemies(flag='theme2'):
            p.scores = 0
            p.hero_jumping = False
            p.counter_jump = 35
            p.hero_y = p.screen_height - p.hero_height - 50
            p.lives = 3
            p.counter_bullets = 0

    def start_game1(self):
        pygame.mixer.music.load('sounds/background.mp3')
        pygame.mixer.music.set_volume(0.3)
        pygame.mixer.music.play(-1)
        while self.main(flag='theme1'):
            p.scores = 0
            p.hero_jumping = False
            p.counter_jump = 35
            p.hero_y = p.screen_height - p.hero_height - 50
            p.lives = 3

    def start_game2(self):
        pygame.mixer.music.load('sounds/background.mp3')
        pygame.mixer.music.set_volume(0.3)
        pygame.mixer.music.play(-1)
        while self.main(flag='theme2'):
            p.scores = 0
            p.hero_jumping = False
            p.counter_jump = 35
            p.hero_y = p.screen_height - p.hero_height - 50
            p.lives = 3
