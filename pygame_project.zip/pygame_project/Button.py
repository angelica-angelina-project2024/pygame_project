from Sounds import *
from Effects import *
from Parameters import screen


class Button:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.button_false = (255, 255, 255)
        self.button_true = (179, 255, 179)
        self.draw_effects = False
        self.clear_effects = False
        self.rect_h = 10
        self.rect_w = width

    def draw(self, x, y, action=None):
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        if x < mouse[0] < x + self.width and y < mouse[1] < y + self.height:
            pygame.draw.rect(screen, self.button_true, (x, y, self.width, self.height))
            if click[0] == 1:
                pygame.mixer.Sound.play(sound_button)
                pygame.time.delay(300)
                if action is not None:
                    action()

        self.draw_beautiful_rect(mouse[0], mouse[1], x, y)

    def draw_beautiful_rect(self, mouse_x, mouse_y, x, y):
        if x <= mouse_x <= x + self.width and y <= mouse_y <= y + self.height:
            self.draw_effects = True

        if self.draw_effects:
            if mouse_x < x or mouse_x > x + self.width or mouse_y < y or mouse_y > y + self.height:
                self.clear_effects = True
                self.draw_effects = False

            if self.rect_h < self.height:
                self.rect_h += (self.height - 10) / 40

        if self.clear_effects and not self.draw_effects:
            if self.rect_h > 10:
                self.rect_h -= (self.height - 10) / 40
            else:
                self.clear_effects = False

        draw_y = y + self.height - self.rect_h
        pygame.draw.rect(screen, self.button_true, (x, draw_y, self.rect_w, self.rect_h))