import pygame

pygame.init()

sound_jump = pygame.mixer.Sound('sounds/sound_cows.mp3')
sound_fall = pygame.mixer.Sound('sounds/crash.mp3')
sound_button = pygame.mixer.Sound('sounds/button.wav')
death_sound = pygame.mixer.Sound('sounds/death.mp3')
crash_sound = pygame.mixer.Sound('sounds/crash.mp3')
shoot_sound = pygame.mixer.Sound('sounds/shoot.mp3')